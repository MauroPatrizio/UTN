package utn.FinalJunit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalJunitApplicationTests {

	@Test
	void contextLoads() {
	}

}
